-- FoodShare / Food Donation Management System
-- Run in Supabase Dashboard -> SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.donations (
  id uuid primary key default gen_random_uuid(),
  donor_name text not null check (char_length(trim(donor_name)) between 1 and 100),
  contact_email text not null check (char_length(trim(contact_email)) <= 254),
  food_name text not null check (char_length(trim(food_name)) between 1 and 120),
  category text not null check (category in ('Cooked Meals','Fruits & Vegetables','Bakery','Packaged Food','Dairy','Other')),
  quantity text not null check (char_length(trim(quantity)) between 1 and 80),
  portions integer not null default 1 check (portions > 0),
  location text not null check (char_length(trim(location)) between 1 and 220),
  available_until timestamptz not null,
  notes text,
  status text not null default 'available' check (status in ('available','claimed','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.claims (
  id uuid primary key default gen_random_uuid(),
  donation_id uuid not null unique references public.donations(id) on delete cascade,
  recipient_name text not null check (char_length(trim(recipient_name)) between 1 and 120),
  recipient_contact text not null check (char_length(trim(recipient_contact)) between 1 and 254),
  status text not null default 'requested' check (status in ('requested','approved','completed','cancelled')),
  created_at timestamptz not null default now()
);

create index if not exists donations_status_deadline_idx on public.donations(status, available_until);
create index if not exists donations_created_at_idx on public.donations(created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists donations_set_updated_at on public.donations;
create trigger donations_set_updated_at before update on public.donations
for each row execute function public.set_updated_at();

-- Atomic claim: only one request can claim a donation.
create or replace function public.claim_donation(
  p_donation_id uuid,
  p_recipient_name text,
  p_recipient_contact text
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  updated_id uuid;
begin
  if p_recipient_name is null or length(trim(p_recipient_name)) = 0
     or p_recipient_contact is null or length(trim(p_recipient_contact)) = 0 then
    return jsonb_build_object('success', false, 'message', 'Recipient details are required.');
  end if;

  update public.donations
     set status = 'claimed'
   where id = p_donation_id
     and status = 'available'
     and available_until > now()
   returning id into updated_id;

  if updated_id is null then
    return jsonb_build_object('success', false, 'message', 'Donation is no longer available or its deadline has passed.');
  end if;

  insert into public.claims(donation_id, recipient_name, recipient_contact)
  values (updated_id, trim(p_recipient_name), trim(p_recipient_contact));

  return jsonb_build_object('success', true, 'message', 'Claim recorded.');
exception
  when unique_violation then
    return jsonb_build_object('success', false, 'message', 'This donation has already been claimed.');
end;
$$;

-- The browser never accesses Supabase directly. The Node API uses the service-role
-- key privately. RLS is enabled as defense-in-depth; do not expose the service key.
alter table public.donations enable row level security;
alter table public.claims enable row level security;

-- No anon/authenticated policies are created intentionally. All access is through
-- the backend API. Grant the function to service_role only.
revoke all on function public.claim_donation(uuid, text, text) from public;
revoke all on function public.claim_donation(uuid, text, text) from anon, authenticated;
grant execute on function public.claim_donation(uuid, text, text) to service_role;

-- Optional dashboard query for a quick summary:
-- select status, count(*) from public.donations group by status;
